-- Active: 1666097427793@@127.0.0.1@3306@gt_hotel

CREATE DATABASE gt_hotel;

use gt_hotel;

-----------------------Data of Inscription

--

-- Table  `user_form`

--

DROP table IF EXISTS user_form;

CREATE
or
REPLACE
TABLE
    user_form(
        id_user int PRIMARY key AUTO_INCREMENT,
        username VARCHAR(50) NOT NULL,
        mail_user VARCHAR(200) NOT null,
        pass_user varchar(50)
    ) AUTO_INCREMENT = 1;

SELECT * from user_form;

--

-- Table `admin_form`

--

DROP TABLE if EXISTS admin_form;

CREATE
or
REPLACE
Table
    admin_form(
        id_admin int PRIMARY KEY AUTO_INCREMENT,
        name varchar(30) NOT NULL,
        uname VARCHAR(50) not NULL,
        upass VARCHAR(50) not null
    ) AUTO_INCREMENT = 1;

INSERT INTO admin_form
VALUES (
        '',
        'Administateur',
        'admin@admin.ma',
        'Admin/123'
    );

SELECT * from admin_form;

