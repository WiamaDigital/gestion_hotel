<?php
	$conn = new mysqli("localhost", "root", "", "gt_hotel") or die(mysqli_error());

?>
